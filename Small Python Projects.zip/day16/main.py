from menu import Menu, MenuItem
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine


this_menu = Menu()
this_coffee_maker = CoffeeMaker()
this_money_machine = MoneyMachine()

this_menu.__init__()
this_coffee_maker.__init__()
this_money_machine.__init__()

def check_input():
    user_choice = input(f"What would you like? ({this_menu.get_items()}): ")
    if user_choice == "off":
        print("Goodbye.")
        exit()
    elif user_choice == "report":
        this_coffee_maker.report()
        this_money_machine.report()
    else:
        return user_choice

def open():
    is_on = True
    while is_on:
        this_coffee_maker.report()
        user_input = check_input()

        selected_coffee = this_menu.find_drink(user_input)
        if (this_coffee_maker.is_resource_sufficient(selected_coffee)):
            print(f"That would be ${selected_coffee.cost}")

            this_money_machine.make_payment(selected_coffee.cost)

            this_coffee_maker.make_coffee(selected_coffee)

open()