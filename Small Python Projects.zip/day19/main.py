import turtle
from turtle import Turtle, Screen
from random import randint

turtle.colormode(255)

def random_color(turtle):
    turtle.color(randint(0, 255), randint(0, 255), randint(0, 255))

turtles = []
def create_turtle():
    new_turtle = Turtle("turtle")
    random_color(new_turtle)
    new_turtle.penup()
    new_turtle.speed("fast")
    turtles.append(new_turtle)

def create_many_turtles(number):
    for i in range(number):
        create_turtle()

def set_start(width,height):
    height_step = 30
    current_height = 0
    current_width = (-1*(width/2)) + 20
    inc = True
    step = height_step
    for turt in turtles:
        turt.goto(current_width, current_height)
        turt.write(f"{turtles.index(turt)+1}", True, align="center", font=('Arial', 18, 'normal'))
        if inc:
            current_height += step
            step += height_step
            step *= -1
        if not inc:
            current_height += step
            step -= height_step
            step *= -1
        inc = not inc

def is_crossed(finish_line):
    for turtle in turtles:
        if turtle.xcor() > finish_line:
            return True
    return False

def get_winner(finish_line):
    for turtle in turtles:
        if turtle.xcor() > 230:
            return turtle

def move_all():
    for turtle in turtles:
        random_distance = randint(1,20)
        turtle.forward(random_distance)

def game_on(width, user_bet):
    selected_turtle = turtles[user_bet-1]
    finish_line_cor = (width/2) - 20
    while not is_crossed(finish_line_cor):
        move_all()
    if is_crossed(finish_line_cor):
        winner_turtle = get_winner(finish_line_cor)
        if selected_turtle == winner_turtle:
            print(f"YOU WON! Your selection was number {user_bet}")
        else:
            print(f"YOU LOSE! The winner is {turtles.index(winner_turtle)+1} Your selection was number {user_bet}")


screen_width = 1000
screen_height = 800

screen = Screen()
screen.setup(width=screen_width,height=screen_height)

num_of_turts = int(screen.textinput(title="# of turtles",prompt="How many turtles: "))
create_many_turtles(num_of_turts)
set_start(width=screen_width,height=screen_height)

user_bet = int(screen.textinput(title="Make your bet",prompt="Which turtle will win? turtle's number: "))
game_on(screen_width,user_bet)

screen.exitonclick()