MENU = {
    "espresso": {
        "ingredients": {
            "water": 50,
            "coffee": 18,
        },
        "cost": 1.5,
    },
    "latte": {
        "ingredients": {
            "water": 200,
            "milk": 150,
            "coffee": 24,
        },
        "cost": 2.5,
    },
    "cappuccino": {
        "ingredients": {
            "water": 250,
            "milk": 100,
            "coffee": 24,
        },
        "cost": 3.0,
    }
}

resources = {
    "water": 300,
    "milk": 200,
    "coffee": 100,
    "money": 0
}

coins = {
    "quarters": 0.25,
    "dimes": 0.1,
    "nickles": 0.05,
    "pennies": 0.01
}


def print_report():
    print(f"Water: {resources['water']}ml\n"
          f"Milk: {resources['milk']}ml\n"
          f"Coffee: {resources['coffee']}g\n"
          f"Money: ${resources['money']}")


def check_sufficiency(beverage):
    if beverage != 'espresso':
        if MENU[beverage]['ingredients']['milk'] > resources['milk']:
            print("Not enough milk!")
            return False

    if resources['money'] < MENU[beverage]['cost']:
        print("Not enough money inserted!")
        return False
    elif MENU[beverage]['ingredients']['water'] > resources['water']:
        print("Not enough water!")
        return False
    elif MENU[beverage]['ingredients']['coffee'] > resources['coffee']:
        print("Not enough coffee!")
        return False
    else:
        return True


def return_money():
    print(f"Here is your money back: {resources['money']}")


def make_coffee(beverage):
    print_cost(beverage)
    insert_coin()
    if check_sufficiency(beverage):
        print("Here is your drink!")
        resources['water'] -= MENU[beverage]['ingredients']['water']
        resources['coffee'] -= MENU[beverage]['ingredients']['coffee']
        resources['money'] -= MENU[beverage]['cost']
        if beverage != 'espresso':
            resources['milk'] -= MENU[beverage]['ingredients']['milk']
        return_money()
        another()
    else:
        print("Some resources were not sufficient. Please check the requirements before trying again.")
        return_money()


def turn_off():
    print("\n----------------------\nTurning off, Goodbye.")
    exit()


def insert_coin():
    print("Please insert coins")
    quarter = check_input(int(input("How many quarters?: ")))
    dime = check_input(int(input("How many dimes?: ")))
    nickle = check_input(int(input("How many nickles?: ")))
    pennie = check_input(int(input("How many pennies?: ")))
    total_amount = round((coins['quarters']*quarter)+(coins['dimes']*dime)+(coins['nickles']*nickle)+(coins['pennies']*pennie), 2)
    resources['money'] += total_amount


def print_cost(drink_choice):
    print(f"That would be ${MENU[drink_choice]['cost']}")


def another():
    print_report()
    answer = check_input(input("Would you like to order another? ('y'/'n'): "))
    if answer == "n":
        turn_off()
    elif answer == "y":
        menu()
    else:
        print("Wrong input, Try again.")
        another()


def check_input(user_input):
    if user_input == "off":
        turn_off()
    else:
        return user_input


def menu():
    print("Welcome to the coffee machine!")
    print_report()
    drink_choice = check_input(input("What would you like? (espresso/latte/cappuccino): ").lower())
    if drink_choice == "off":
        turn_off()
    elif drink_choice == "report":
        print_report()
    elif drink_choice == "espresso" or drink_choice == "latte" or drink_choice == "cappuccino":
        make_coffee(drink_choice)
    else:
        print("Wrong input, Try again.")
        menu()


menu()
