from turtle import Turtle
from random import randint


class Food(Turtle):

    def __init__(self, screen_width, screen_height):
        super().__init__()
        self.shape("circle")
        self.penup()
        self.shapesize(stretch_wid=0.5, stretch_len=0.5)
        self.color("light blue")
        self.speed("fastest")

        self.screen_w = round(screen_width/2)
        self.screen_h = round(screen_height/2)
        self.refresh()

    def refresh(self):
        half_screen_width = abs(self.screen_w - 24)
        half_screen_height = abs(self.screen_h - 24)
        rand_x = randint(((-1) * half_screen_width), half_screen_width)
        rand_y = randint(((-1) * half_screen_height), half_screen_height)
        self.goto(rand_x, rand_y)

