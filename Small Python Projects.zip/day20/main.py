from turtle import Screen
from PySnake import pySnake
from food import Food
from scoreboard import Scoreboard
from border import Borders
import time


screen_width = 800
screen_height = 800
screen = Screen()
screen.setup(width=screen_width, height=screen_height)
screen.bgcolor("black")
screen.title("=Snake Game=")
screen.tracer(0)


snake = pySnake("square", 7)
food = Food(screen_width, screen_height)
score = Scoreboard(screen_height)
screen_border = Borders(screen_width, screen_height)
screen.update()


screen.listen()
screen.onkey(snake.up, "Up")
screen.onkey(snake.down, "Down")
screen.onkey(snake.left, "Left")
screen.onkey(snake.right, "Right")


def play_a_round(is_on):
    sleep_time = 0.1
    while is_on:
        screen.update()
        time.sleep(sleep_time)
        snake.move_snake()

        if snake.snake_head.distance(food) < 15:
            food.refresh()
            score.nom_nom()
            snake.add_tail()
            sleep_time -= 0.001

        north_border = screen_border.get_ycor_border()
        south_border = (-1) * screen_border.get_ycor_border()
        west_border = (-1) * screen_border.get_xcor_border()
        east_border = screen_border.get_xcor_border()
        snake_head_xcor = snake.snake_head.xcor()
        snake_head_ycor = snake.snake_head.ycor()
        if snake_head_xcor > east_border or snake_head_xcor < west_border or snake_head_ycor > north_border \
                or snake_head_ycor < south_border:

            is_on = False
            score.game_over()

        if snake.detect_collision():
            is_on = False
            score.game_over()


def snake_game():
    play_a_round(True)

    again_input = screen.textinput(title="Play Again?", prompt="Would you like to play again?(y/n)")
    if again_input == "y":
        play_a_round(True)
    elif again_input == "n":
        screen.bye()


snake_game()
screen.exitonclick()
