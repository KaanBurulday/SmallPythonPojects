from turtle import Turtle
MOVE_DISTANCE = 20
UP = 90
DOWN = 270
LEFT = 180
RIGHT = 0


class pySnake:

    def __init__(self, shape, lenght):
        self.snake = []
        self.snake_length = lenght
        self.snake_shape = shape
        self.create_snake()
        self.snake_head = self.snake[0]

    def create_snake(self):
        for part in range(self.snake_length):
            box = Turtle(self.snake_shape)
            box.penup()
            box.color("white")
            if len(self.snake) == 0:
                self.snake.append(box)
            else:
                distance = abs(self.snake[len(self.snake) - 1].xcor()) + 20
                self.snake.append(box)
                box.back(distance)

    def move_snake(self):
        for snake_seq in range(len(self.snake) - 1, 0, -1):
            xcor = self.snake[snake_seq - 1].xcor()
            ycor = self.snake[snake_seq - 1].ycor()
            next_heading = self.snake[snake_seq - 1].heading()
            self.snake[snake_seq].goto(xcor, ycor)
            self.snake[snake_seq].setheading(next_heading)
        self.snake_head.forward(MOVE_DISTANCE)

    def add_tail(self):
        box = Turtle(self.snake_shape)
        box.penup()
        box.color("white")
        self.snake.append(box)

    def detect_collision(self):
        for part in self.snake[1:]:
            if self.snake_head.distance(part) < 19:
                return True
        return False

    def direct_snake(self, degree):
        self.snake_head.setheading(degree)

    def left(self):
        if self.snake_head.heading() != RIGHT:
            self.direct_snake(LEFT)

    def right(self):
        if self.snake_head.heading() != LEFT:
            self.direct_snake(RIGHT)

    def up(self):
        if self.snake_head.heading() != DOWN:
            self.direct_snake(UP)

    def down(self):
        if self.snake_head.heading() != UP:
            self.direct_snake(DOWN)
