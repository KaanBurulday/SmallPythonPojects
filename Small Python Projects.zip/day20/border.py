from turtle import Turtle


class Borders(Turtle):

    def __init__(self, screen_width, screen_height):
        super().__init__()
        self.xcor_distance = int(((screen_width/2) - 20)*2)
        self.ycor_distance = int(((screen_height/2) - 20)*2)

        self.hideturtle()
        self.penup()
        self.color("white")

        self.xcor_start = int((-1) * (screen_width / 2) + 20)
        self.ycor_start = int((-1) * (screen_height / 2) + 20)
        self.goto(self.xcor_start, self.ycor_start)
        self.pendown()
        self.forward(self.xcor_distance)
        self.left(90)
        self.forward(self.ycor_distance)
        self.left(90)
        self.forward(self.xcor_distance)
        self.left(90)
        self.forward(self.ycor_distance)

    def get_xcor_border(self):
        return int(self.xcor_distance/2)

    def get_ycor_border(self):
        return int(self.ycor_distance/2)
