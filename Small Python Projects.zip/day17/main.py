from question_model import Question
from quiz_brain import QuizBrain
from data import question_data
from random import randint


def create_data_bank():
    question_bank = []
    for element in range(0, len(question_data)):
        random_index = randint(0, len(question_data) - 1)
        question = Question(question_data[random_index]["text"], question_data[random_index]["answer"])
        question_data.remove(question_data[random_index])
        question_bank.append(question)
    return question_bank

def game_on():
    quiz = QuizBrain(create_data_bank())

    while quiz.still_has_questions():
        quiz.next_question()

    print(f"You've completed the quiz. Your final score is: {quiz.score}/{quiz.question_number}")

game_on()