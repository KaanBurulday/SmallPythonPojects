import turtle as t
from random import randint
import colorgram


def get_colors_from_image():
    rgb_colors = []
    colors = colorgram.extract('image3.jpg', 30)
    for color in colors:
        rgb_colors.append(color.rgb)
    return rgb_colors

t.shapesize(3,3,3)
t.colormode(255)

t.speed(15)
t.pensize(5)

default_forward_amount = 50

def random_color():
    t.color(randint(0, 255), randint(0, 255), randint(0, 255))

def draw_shapes():
    is_on = True
    corners = 3
    while is_on:
        random_color()
        turn_angle = 360 / corners
        for i in range(corners):
            t.forward(default_forward_amount)
            t.right(turn_angle)
        corners += 1

def random_walk():
    is_on = True
    angles = [0,90,180,270]
    while is_on:
        t.setheading(angles[randint(0,len(angles)-1)])
        t.forward(default_forward_amount)
        random_color()

def draw_spirograph(size_of_gap):
    is_on = True
    angle = size_of_gap
    repeat_times = int(360/size_of_gap)
    for i in range(repeat_times):
        t.circle(100)
        t.setheading(angle)
        angle += size_of_gap
        random_color()

def draw_dots_square(square_size):
    color_bank = get_colors_from_image()

    for x in range(square_size):
        for y in range(square_size):
            t.pendown()
            t.dot(25, color_bank[randint(0, len(color_bank) - 1)])
            t.penup()
            t.forward(default_forward_amount)

        total_distance = square_size * default_forward_amount
        t.back(total_distance)
        t.left(90)
        t.forward(default_forward_amount)
        t.right(90)


draw_dots_square(7)

screen = t.Screen()
screen.exitonclick()

